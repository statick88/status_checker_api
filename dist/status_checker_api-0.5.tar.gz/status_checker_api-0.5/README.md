# API Status Checker

![Example](/img/paste-5.png)

Un paquete para verificar el estado de una API.

## Instalación

```bash
pip install api_status_checker
```

# Uso


```bash
api-status-checker
```

# Ejemplo

```bash
api-status-checker --url https://api.github.com
```

